@echo off
echo === Building P&ID Legend Release APK ===
call flutter pub get
call flutter build apk --release
echo APK compiled successfully at: build\app\outputs\flutter-apk\app-release.apk
pause
