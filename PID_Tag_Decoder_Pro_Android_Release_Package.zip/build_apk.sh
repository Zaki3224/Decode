#!/bin/bash
echo "=== Building P&ID Legend & Tag Decoder Release APK ==="
flutter pub get
flutter build apk --release
echo "APK compiled successfully at: build/app/outputs/flutter-apk/app-release.apk"
