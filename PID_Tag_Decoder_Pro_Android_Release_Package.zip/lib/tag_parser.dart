/// ISA-5.1 Tag Parser for Flutter Android Application
/// Provides offline parsing and real-time breakdown of P&ID instrument tags in English, Arabic, and French.
library tag_parser;

class ParsedLetterToken {
  final String char;
  final String roleEn;
  final String roleAr;
  final String roleFr;
  final String meaningEn;
  final String meaningAr;
  final String meaningFr;
  final String category;

  ParsedLetterToken({
    required this.char,
    required this.roleEn,
    required this.roleAr,
    required this.roleFr,
    required this.meaningEn,
    required this.meaningAr,
    required this.meaningFr,
    required this.category,
  });
}

class TagParseResult {
  final String rawInput;
  final bool isValid;
  final String? variableLetter;
  final String? variableModifier;
  final String variableNameEn;
  final String variableNameAr;
  final String variableNameFr;
  final List<String> functionLetters;
  final List<String> functionNamesEn;
  final List<String> functionNamesAr;
  final List<String> functionNamesFr;
  final String loopNumber;
  final String suffix;
  final String summaryEn;
  final String summaryAr;
  final String summaryFr;
  final String roleExplanationEn;
  final String roleExplanationAr;
  final String roleExplanationFr;
  final List<ParsedLetterToken> tokens;
  final String mountingType;

  TagParseResult({
    required this.rawInput,
    required this.isValid,
    this.variableLetter,
    this.variableModifier,
    required this.variableNameEn,
    required this.variableNameAr,
    required this.variableNameFr,
    required this.functionLetters,
    required this.functionNamesEn,
    required this.functionNamesAr,
    required this.functionNamesFr,
    required this.loopNumber,
    required this.suffix,
    required this.summaryEn,
    required this.summaryAr,
    required this.summaryFr,
    required this.roleExplanationEn,
    required this.roleExplanationAr,
    required this.roleExplanationFr,
    required this.tokens,
    required this.mountingType,
  });

  factory TagParseResult.empty() => TagParseResult(
    rawInput: '',
    isValid: false,
    variableNameEn: '',
    variableNameAr: '',
    variableNameFr: '',
    functionLetters: [],
    functionNamesEn: [],
    functionNamesAr: [],
    functionNamesFr: [],
    loopNumber: '',
    suffix: '',
    summaryEn: 'Enter an instrument tag (e.g. PIT-101)',
    summaryAr: 'أدخل وسم أجهزة (مثل PIT-101)',
    summaryFr: 'Entrez un repère (ex: PIT-101)',
    roleExplanationEn: 'Type an instrument tag above to view ISA-5.1 breakdown.',
    roleExplanationAr: 'اكتب وسم الجهاز في الحقل أعلاه لمشاهدة التحليل.',
    roleExplanationFr: 'Saisissez un repère pour afficher l\'analyse ISA-5.1.',
    tokens: [],
    mountingType: 'field',
  );
}

class IsaTagParser {
  final Map<String, dynamic> _variables;
  final Map<String, dynamic> _varModifiers;
  final Map<String, dynamic> _succeeding;
  final Map<String, dynamic> _succModifiers;

  IsaTagParser({
    required Map<String, dynamic> variables,
    required Map<String, dynamic> varModifiers,
    required Map<String, dynamic> succeeding,
    required Map<String, dynamic> succModifiers,
  })  : _variables = variables,
        _varModifiers = varModifiers,
        _succeeding = succeeding,
        _succModifiers = succModifiers;

  TagParseResult parse(String input) {
    final clean = input.trim().toUpperCase();
    if (clean.isEmpty) return TagParseResult.empty();

    final regExp = RegExp(r'^([A-Z]+)(?:[-_\\s]*)([0-9]*)([A-Z]?)$');
    final match = regExp.firstMatch(clean);
    if (match == null) return TagParseResult.empty();

    final rawLetters = match.group(1) ?? '';
    final loopNumber = match.group(2) ?? '';
    final suffix = match.group(3) ?? '';

    final firstChar = rawLetters[0];
    final varData = _variables[firstChar];
    if (varData == null) return TagParseResult.empty();

    final tokens = <ParsedLetterToken>[];
    tokens.add(ParsedLetterToken(
      char: firstChar,
      roleEn: 'Measured Variable',
      roleAr: 'المتغير المقاس',
      roleFr: 'Variable Mesurée',
      meaningEn: '${varData["nameEn"]} (${varData["descEn"]})',
      meaningAr: '${varData["nameAr"]} (${varData["descAr"]})',
      meaningFr: '${varData["nameFr"] ?? varData["nameEn"]}',
      category: 'variable',
    ));

    String remaining = rawLetters.substring(1);
    String? varModifier;

    if (remaining.isNotEmpty) {
      final cand = remaining[0];
      final isSafety = (cand == 'S' && remaining.length > 1 && remaining[1] == 'V');
      if (_varModifiers.containsKey(cand) && (cand != 'S' || isSafety)) {
        varModifier = cand;
        final modData = _varModifiers[cand];
        tokens.add(ParsedLetterToken(
          char: cand,
          roleEn: 'Variable Modifier',
          roleAr: 'معدل المتغير',
          roleFr: 'Modificateur',
          meaningEn: '${modData["nameEn"]}: ${modData["descEn"]}',
          meaningAr: '${modData["nameAr"]}: ${modData["descAr"]}',
          meaningFr: '${modData["nameFr"] ?? modData["nameEn"]}',
          category: 'modifier',
        ));
        remaining = remaining.substring(1);
      }
    }

    final funcLetters = <String>[];
    final funcNamesEn = <String>[];
    final funcNamesAr = <String>[];
    final funcNamesFr = <String>[];

    for (int i = 0; i < remaining.length; i++) {
      final ch = remaining[i];
      final f = _succeeding[ch];
      if (f != null) {
        funcLetters.add(ch);
        funcNamesEn.add(f['nameEn']);
        funcNamesAr.add(f['nameAr']);
        funcNamesFr.add(f['nameFr'] ?? f['nameEn']);
        tokens.add(ParsedLetterToken(
          char: ch,
          roleEn: f['type'] == 'readout' ? 'Readout Function' : 'Output Action',
          roleAr: f['type'] == 'readout' ? 'وظيفة قراءة' : 'وظيفة تحكم',
          roleFr: f['type'] == 'readout' ? 'Affichage' : 'Action',
          meaningEn: '${f["nameEn"]}: ${f["descEn"]}',
          meaningAr: '${f["nameAr"]}: ${f["descAr"]}',
          meaningFr: '${f["nameFr"] ?? f["nameEn"]}',
          category: f['type'],
        ));
      }
    }

    if (loopNumber.isNotEmpty) {
      tokens.add(ParsedLetterToken(
        char: loopNumber + suffix,
        roleEn: 'Loop Identification',
        roleAr: 'رقم حلقة التحكم',
        roleFr: 'Numéro de Boucle',
        meaningEn: 'Loop #$loopNumber$suffix',
        meaningAr: 'حلقة رقم #$loopNumber$suffix',
        meaningFr: 'Boucle #$loopNumber$suffix',
        category: 'loop',
      ));
    }

    final varDisplayNameEn = varModifier != null
        ? '${_varModifiers[varModifier]?["nameEn"] ?? ""} ${varData["nameEn"]}'
        : varData["nameEn"];
    final varDisplayNameAr = varModifier != null
        ? '${_varModifiers[varModifier]?["nameAr"] ?? ""} ${varData["nameAr"]}'
        : varData["nameAr"];
    final varDisplayNameFr = varModifier != null
        ? '${varData["nameFr"] ?? varData["nameEn"]} ${_varModifiers[varModifier]?["nameFr"] ?? ""}'
        : (varData["nameFr"] ?? varData["nameEn"]);

    final summaryEn = '$varDisplayNameEn ${funcNamesEn.join(" ")}${loopNumber.isNotEmpty ? " (Loop $loopNumber$suffix)" : ""}';
    final summaryAr = '${funcNamesAr.join(" / ")} - $varDisplayNameAr${loopNumber.isNotEmpty ? " (الحلقة $loopNumber$suffix)" : ""}';
    final summaryFr = '${funcNamesFr.join(" ")} de $varDisplayNameFr${loopNumber.isNotEmpty ? " (Boucle $loopNumber$suffix)" : ""}';

    String mounting = 'field';
    if (funcLetters.contains('C')) mounting = 'dcs';
    else if (funcLetters.contains('A')) mounting = 'panel';
    else if (rawLetters.startsWith('X') || funcLetters.contains('K')) mounting = 'plc';

    return TagParseResult(
      rawInput: input,
      isValid: true,
      variableLetter: firstChar,
      variableModifier: varModifier,
      variableNameEn: varDisplayNameEn,
      variableNameAr: varDisplayNameAr,
      variableNameFr: varDisplayNameFr,
      functionLetters: funcLetters,
      functionNamesEn: funcNamesEn,
      functionNamesAr: funcNamesAr,
      functionNamesFr: funcNamesFr,
      loopNumber: loopNumber,
      suffix: suffix,
      summaryEn: summaryEn,
      summaryAr: summaryAr,
      summaryFr: summaryFr,
      roleExplanationEn: 'Calibrated industrial device according to ISA-5.1 standards.',
      roleExplanationAr: 'جهاز صناعي معاير وفق معايير ISA-5.1 القياسية.',
      roleExplanationFr: 'Instrument industriel normalisé selon la norme ISA-5.1.',
      tokens: tokens,
      mountingType: mounting,
    );
  }
}