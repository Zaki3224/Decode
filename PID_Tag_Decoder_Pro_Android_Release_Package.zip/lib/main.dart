import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'tag_parser.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const PidLegendApp());
}

class PidLegendApp extends StatefulWidget {
  const PidLegendApp({super.key});

  @override
  State<PidLegendApp> createState() => _PidLegendAppState();
}

class _PidLegendAppState extends State<PidLegendApp> {
  Locale _currentLocale = const Locale('ar'); // Default to Arabic RTL
  ThemeMode _themeMode = ThemeMode.dark;

  void _cycleLocale() {
    setState(() {
      if (_currentLocale.languageCode == 'ar') {
        _currentLocale = const Locale('en');
      } else if (_currentLocale.languageCode == 'en') {
        _currentLocale = const Locale('fr');
      } else {
        _currentLocale = const Locale('ar');
      }
    });
  }

  void _toggleTheme() {
    setState(() {
      _themeMode = _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Engineering Navy (#1A2B4C), Safety Orange (#FF9F1C), and Safety Cyan (#00A8CC)
    const primaryNavy = Color(0xFF1A2B4C);
    const safetyOrange = Color(0xFFFF9F1C);
    const safetyCyan = Color(0xFF00A8CC);

    return MaterialApp(
      title: 'P&ID Legend & Tag Decoder Pro',
      debugShowCheckedModeBanner: false,
      locale: _currentLocale,
      themeMode: _themeMode,
      supportedLocales: const [
        Locale('ar', ''),
        Locale('en', ''),
        Locale('fr', ''),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF4F6F9),
        primaryColor: primaryNavy,
        colorScheme: const ColorScheme.light(
          primary: primaryNavy,
          secondary: safetyOrange,
          tertiary: safetyCyan,
          surface: Colors.white,
          onPrimary: Colors.white,
        ),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(ThemeData.light().textTheme),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D182A),
        primaryColor: safetyCyan,
        colorScheme: const ColorScheme.dark(
          primary: safetyCyan,
          secondary: safetyOrange,
          surface: Color(0xFF15223A),
          onPrimary: Color(0xFF0D182A),
          onSurface: Color(0xFFF0F4F8),
        ),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(ThemeData.dark().textTheme),
      ),
      home: HomeScreen(
        onToggleLocale: _cycleLocale,
        onToggleTheme: _toggleTheme,
        isDarkMode: _themeMode == ThemeMode.dark,
        currentLocale: _currentLocale,
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final VoidCallback onToggleLocale;
  final VoidCallback onToggleTheme;
  final bool isDarkMode;
  final Locale currentLocale;

  const HomeScreen({
    super.key,
    required this.onToggleLocale,
    required this.onToggleTheme,
    required this.isDarkMode,
    required this.currentLocale,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  IsaTagParser? _parser;
  Map<String, dynamic>? _isaData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadIsaData();
  }

  Future<void> _loadIsaData() async {
    try {
      final jsonStr = await rootBundle.loadString('assets/isa_data.json');
      final data = json.decode(jsonStr) as Map<String, dynamic>;
      setState(() {
        _isaData = data;
        _parser = IsaTagParser(
          variables: data['variables'] ?? {},
          varModifiers: data['variableModifiers'] ?? {},
          succeeding: data['succeedingLetters'] ?? {},
          succModifiers: data['succeedingModifiers'] ?? {},
        );
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = widget.currentLocale.languageCode;
    final isAr = lang == 'ar';
    final isFr = lang == 'fr';

    final title = isAr
        ? 'محلل وسوم P&ID برو'
        : isFr
        ? 'P&ID Décodeur Pro'
        : 'P&ID Legend & Tag Decoder Pro';

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const Text('ISA-5.1 Instrumentation', style: TextStyle(fontSize: 11, color: Color(0xFF90A4AE))),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Dark / Light',
            icon: Icon(widget.isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: widget.onToggleTheme,
          ),
          IconButton(
            tooltip: 'Language',
            icon: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFF00A8CC)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                isAr ? 'عربي' : isFr ? 'FR' : 'EN',
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF00A8CC)),
              ),
            ),
            onPressed: widget.onToggleLocale,
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : IndexedStack(
              index: _currentIndex,
              children: [
                DecoderScreen(parser: _parser, lang: lang),
                SymbolsScreen(isaData: _isaData, lang: lang),
              ],
            ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.qr_code_scanner),
            label: isAr ? 'محلل الوسوم' : isFr ? 'Décodeur' : 'Tag Decoder',
          ),
          NavigationDestination(
            icon: const Icon(Icons.menu_book),
            label: isAr ? 'مكتبة الرموز' : isFr ? 'Symboles' : 'Symbols Library',
          ),
        ],
      ),
    );
  }
}

class DecoderScreen extends StatefulWidget {
  final IsaTagParser? parser;
  final String lang;
  const DecoderScreen({super.key, required this.parser, required this.lang});

  @override
  State<DecoderScreen> createState() => _DecoderScreenState();
}

class _DecoderScreenState extends State<DecoderScreen> {
  final TextEditingController _controller = TextEditingController(text: 'PIT-101');
  late TagParseResult _currentResult;

  final List<String> _quickTags = [
    'PIT-101', 'LIC-204', 'PSV-12', 'FCV-105A',
    'TT-301', 'PDIC-401', 'LAH-102', 'XV-001'
  ];

  @override
  void initState() {
    super.initState();
    _reparse(_controller.text);
  }

  void _reparse(String tag) {
    if (widget.parser == null) return;
    setState(() {
      _currentResult = widget.parser!.parse(tag);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isAr = widget.lang == 'ar';
    final isFr = widget.lang == 'fr';

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: _controller,
            textCapitalization: TextCapitalization.characters,
            style: GoogleFonts.jetBrainsMono(fontSize: 20, fontWeight: FontWeight.bold),
            decoration: InputDecoration(
              labelText: isAr ? 'أدخل رمز الجهاز (مثل PIT-101)' : 'Enter P&ID Tag',
              filled: true,
              prefixIcon: const Icon(Icons.search, color: Color(0xFF00A8CC)),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            ),
            onChanged: _reparse,
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _quickTags.map((tag) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ActionChip(
                  label: Text(tag, style: GoogleFonts.jetBrainsMono(fontSize: 12, fontWeight: FontWeight.bold)),
                  onPressed: () {
                    _controller.text = tag;
                    _reparse(tag);
                  },
                ),
              )).toList(),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Visual Field vs Control Room Indicator
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Chip(
                        avatar: Icon(
                          _currentResult.mountingType == 'field' ? Icons.location_on : Icons.computer,
                          size: 16,
                          color: const Color(0xFF00A8CC),
                        ),
                        label: Text(
                          _currentResult.mountingType == 'field'
                              ? (isAr ? 'مثبت حقلياً (Field)' : 'Field-Mounted')
                              : (isAr ? 'غرفة التحكم / DCS' : 'Control Room / DCS'),
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const Text('ISA-5.1', style: TextStyle(fontFamily: 'monospace', color: Color(0xFFFF9F1C))),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    isAr ? _currentResult.summaryAr : isFr ? _currentResult.summaryFr : _currentResult.summaryEn,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFF00A8CC)),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isAr ? _currentResult.roleExplanationAr : isFr ? _currentResult.roleExplanationFr : _currentResult.roleExplanationEn,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 13, height: 1.4),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(isAr ? 'التحليل التفصيلي للحروف' : 'Letter-by-Letter Breakdown', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ..._currentResult.tokens.map((token) => Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFF00A8CC).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFF00A8CC)),
                ),
                child: Text(token.char, style: GoogleFonts.jetBrainsMono(fontSize: 18, fontWeight: FontWeight.bold, color: const Color(0xFF00A8CC))),
              ),
              title: Text(isAr ? token.roleAr : isFr ? token.roleFr : token.roleEn, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              subtitle: Text(isAr ? token.meaningAr : isFr ? token.meaningFr : token.meaningEn, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
            ),
          )),
        ],
      ),
    );
  }
}

class SymbolsScreen extends StatelessWidget {
  final Map<String, dynamic>? isaData;
  final String lang;
  const SymbolsScreen({super.key, required this.isaData, required this.lang});

  @override
  Widget build(BuildContext context) {
    final symbols = (isaData?['symbols'] as List<dynamic>?) ?? [];
    final isAr = lang == 'ar';
    final isFr = lang == 'fr';

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: symbols.length,
      itemBuilder: (ctx, i) {
        final s = symbols[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: const Color(0xFF1A2B4C),
              child: Text(s['isaCode'] ?? '', style: const TextStyle(fontSize: 10, color: Color(0xFF00A8CC), fontWeight: FontWeight.bold)),
            ),
            title: Text(isAr ? s['nameAr'] : isFr ? s['nameFr'] : s['nameEn'], style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(isAr ? s['descAr'] : isFr ? s['descFr'] : s['descEn']),
          ),
        );
      },
    );
  }
}