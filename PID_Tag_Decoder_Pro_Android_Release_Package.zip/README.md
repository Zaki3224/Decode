# How to Build & Download APK for Android

### Method 1: 1-Click Cloud APK Build via GitHub Actions (Free)
1. Push this folder to a GitHub repository.
2. Go to the "Actions" tab in GitHub.
3. Click "Build Android Release APK" -> "Run workflow".
4. Within 2 minutes, download the signed 'app-release.apk' from Artifacts on your phone!

### Method 2: Codemagic / Appcircle Cloud Build
- Connect your GitHub repo to codemagic.io.
- Run the Android build pipeline to get direct APK download link.

### Method 3: Local Terminal Build (Flutter CLI)
```bash
flutter pub get
flutter build apk --release
```
The APK file is generated at:
`build/app/outputs/flutter-apk/app-release.apk`

### Method 4: Instant WebAPK Install on Android Phone
Open this app on Android Chrome and click "Install App" to install directly on your home screen without compiling!